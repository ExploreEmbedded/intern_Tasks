#include "snake.h"
#include "tm_stm32f4_rng.h"

void setup()
{
		GameOver = 0;
    D = STOP;
		dold = STOP;
//    snakex = width/2;
//    snakey = height/2;
	TM_RNG_Init();
	f = TM_RNG_Get() % (width-2);
    foodx = f - (f%5);
  f = TM_RNG_Get() % (height-2);  
		foody = f - (f%5);
    score = 0;
	
		//startflag = 0;
}
void draw()
{		
		TM_ILI9341_DrawLine(2,2,2,238,ILI9341_COLOR_WHITE);	//LHS border
		TM_ILI9341_DrawLine(2,2,318,2,ILI9341_COLOR_WHITE);	//bottom border
		TM_ILI9341_DrawLine(2,238,318,238,ILI9341_COLOR_WHITE);	//top border
		TM_ILI9341_DrawLine(318,238,318,2,ILI9341_COLOR_WHITE);//RHS border
	
		for(k=0; k<ntail; k++)
		{// last co ordinates in tailx/y arrays is of head
				if(k == (ntail-1))
						TM_ILI9341_DrawFilledCircle(tailx[k],taily[k],2,ILI9341_COLOR_RED);
				else
						TM_ILI9341_DrawFilledCircle(tailx[k],taily[k],2,ILI9341_COLOR_WHITE);
		}
		TM_ILI9341_DrawFilledCircle(foodx,foody,2,ILI9341_COLOR_YELLOW);
		// convert score to string and display on lcd
		sprintf(s,"%4d \n\r",score);
		TM_ILI9341_Puts(0,229,s,&TM_Font_7x10,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
		if(flagclear == 1) 
		{
				TM_ILI9341_DrawFilledCircle(xtail, ytail,2,ILI9341_COLOR_BLACK);
				flagclear = 0;
		}
		if(score == 5)
		{
				GameOver = 1;
				TM_ILI9341_Puts(0,0,"YOU WIN !!!",&TM_Font_16x26,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
		}
}
void input()
{ 
		if (TM_ADC_Read(ADC1, ADC_Channel_0) < 1900)
		{
				D = UP;
				//TM_ILI9341_DrawFilledCircle(160, 120, 10, ILI9341_COLOR_BLUE);
		}
		else if (TM_ADC_Read(ADC1, ADC_Channel_0) > 2100)
		{
				D = DOWN;
			if(startflag == 0)
			{
					D = STOP;
					startflag = 1;
			}
				//TM_ILI9341_DrawFilledCircle(160, 120, 10, ILI9341_COLOR_ORANGE);
		}
		else if (TM_ADC_Read(ADC1, ADC_Channel_3) < 1900)
		{
				D = RIGHT;
				//TM_ILI9341_DrawFilledCircle(160, 120, 10, ILI9341_COLOR_RED);
		}
		else if (TM_ADC_Read(ADC1, ADC_Channel_3) > 2100)
		{
				D = LEFT;
				//TM_ILI9341_DrawFilledCircle(160, 120, 10, ILI9341_COLOR_GREEN);
		}
		else
		{
			//	D = STOP;//TM_ILI9341_DrawFilledCircle(160, 120, 10, ILI9341_COLOR_WHITE);
		}
}
void logic()
{
		snakex = tailx[ntail-1];	
		snakey = taily[ntail-1];
		switch(D)
		{
			case UP:
				if(snakey<=2)
        {//print gameover
					TM_ILI9341_Puts(0,0,"GAME OVER !!!",&TM_Font_16x26,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
					
           //cout<<"GAME OVER!!";
           GameOver=1;
          // cout<<score;
					sprintf(s,"%4d \n\r",score);
					TM_ILI9341_Puts(0,230,s,&TM_Font_7x10,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
           break;
        }
			if(dold != DOWN)
			{snakey = snakey - 5;}
			else
			{snakey = snakey + 5;
				D = DOWN;}
			
        break;
    case DOWN :
        if(snakey>=height-2)
        {
						TM_ILI9341_Puts(0,0,"GAME OVER !!!",&TM_Font_16x26,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
          // cout<<"GAME OVER!!";
           GameOver=1;
          // cout<<score;
					sprintf(s,"%4d \n\r",score);
					TM_ILI9341_Puts(0,230,s,&TM_Font_7x10,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
           break;
        }
		if(dold != UP)
        snakey = snakey + 5;
		else
			{snakey = snakey - 5; D = UP;}
        break;
    case LEFT :
        if(snakex<=2)
         {
					 	TM_ILI9341_Puts(0,0,"GAME OVER !!!",&TM_Font_16x26,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
       //    cout<<"GAME OVER!!";
           GameOver=1;
           //cout<<score;
					 sprintf(s,"%4d \n\r",score);
		TM_ILI9341_Puts(0,230,s,&TM_Font_7x10,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
           break;
        }
		if(dold != RIGHT)
        snakex = snakex - 5;
		else 
		{snakex = snakex + 5; D = RIGHT;}
        break;
    case RIGHT :
        if(snakex>=width-2)
        {
						TM_ILI9341_Puts(0,0,"GAME OVER !!!",&TM_Font_16x26,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
          // cout<<"   GAME OVER!!";
           GameOver=1;
sprintf(s,"%4d \n\r",score);
		TM_ILI9341_Puts(0,230,s,&TM_Font_7x10,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
           break;
        }
		if(dold != LEFT)
        snakex = snakex + 5;
		else
		{snakex = snakex - 5;D = LEFT;}
        break;
    default :
        break;
    }
		
		
		dold = D;
		if((D != STOP))
		{
			xtail = tailx[0];
			ytail = taily[0];
			
		for(i=0; i<ntail-1; i++)
		{
				tailx[i] = tailx[i+1];
				taily[i] = taily[i+1];
		}
		
		tailx[ntail-1] = snakex;
		taily[ntail-1] = snakey;
		flagclear = 1;
// in draw function
		//		TM_ILI9341_DrawFilledCircle(xtail, ytail,2,ILI9341_COLOR_BLACK);
	}
		if(dold == D){
    for(int i=0;i<ntail-1;i++)
    {
       if(tailx[i]==snakex && taily[i]==snakey)
       {
          	TM_ILI9341_Puts(0,0,"GAME OVER !!!",&TM_Font_16x26,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
           GameOver=1;
       }
    }
	}
    if((snakex==foodx) && (snakey==foody))
    {
			f = rand() % (width-2);
         foodx = f - (f%5);
			f = rand() % (height-2);
			foody = f - (f%5);
         score++;
					tailx[ntail] = snakex;
					taily[ntail] = snakey;
			ntail++;
				
    }
		
		}
