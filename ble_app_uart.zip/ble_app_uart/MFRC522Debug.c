
#include "MFRC522Debug.h"

/**
 * Returns a __FlashStringHelper pointer to the PICC type name.
 *
 * @return const __FlashStringHelper *
 */
 const char* PICC_GetTypeNameExtended(PICC_Type piccType	///< One of the PICC_Type enums.
) {
	char* a ="PICC compliant with ISO/IEC 14443-4";
	char* b="PICC compliant with ISO/IEC 18092 (NFC)";
	char* c="MIFARE Mini, 320 bytes";
	char* d="MIFARE 1KB";
	char* e="MIFARE 4KB";
	char* f="MIFARE Ultralight or Ultralight C";
	char* g="MIFARE Plus";
	char* h="MIFARE DESFire";
	char* i="MIFARE TNP3XXX";
	char* j="SAK indicates UID is not complete.";
	char* k="Unknown type";
	
	switch (piccType) {
		case PICC_TYPE_ISO_14443_4:		return a;
		case PICC_TYPE_ISO_18092:		return b;
		case PICC_TYPE_MIFARE_MINI:		return c;
		case PICC_TYPE_MIFARE_1K:		return d;
		case PICC_TYPE_MIFARE_4K:		return e;
		case PICC_TYPE_MIFARE_UL:		return f;
		case PICC_TYPE_MIFARE_PLUS:		return g;
		case PICC_TYPE_MIFARE_DESFIRE:	return h;
		case PICC_TYPE_TNP3XXX:			return i;
		case PICC_TYPE_NOT_COMPLETE:	return j;
		case PICC_TYPE_UNKNOWN:
		default:						return k;
	}
} // End PICC_GetTypeName()

/**
 * Returns a __FlashStringHelper pointer to a status code name.
 *
 * @return const __FlashStringHelper *
 */
const char* GetStatusCodeName_(StatusCode code	///< One of the StatusCode enums.
) {
 char* a="Success.";char* b="Error in communication.";char*c="Collission detected.";char*d="Timeout in communication.";
 char*	e="A buffer is not big enough.";char*f="Internal error in the code. Should not happen.";char*g="Invalid argument.";
 char* h="The CRC_A does not match.";char*i="A MIFARE PICC responded with NAK.";char*j="Unknown error";
	switch (code) {
		case STATUS_OK:				return a;
		case STATUS_ERROR:			return b;
		case STATUS_COLLISION:		return c;
		case STATUS_TIMEOUT:		return d;
		case STATUS_NO_ROOM:		return e;
		case STATUS_INTERNAL_ERROR:	return f;
		case STATUS_INVALID:		return g;
		case STATUS_CRC_WRONG:		return h;
		case STATUS_MIFARE_NACK:	return i;
		default:					return j;
	}
} // End GetStatusCodeName()
