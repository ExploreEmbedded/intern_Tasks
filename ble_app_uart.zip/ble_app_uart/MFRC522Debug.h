#include "MFRC522.h"

#ifndef MFRC522Debug_h
#define MFRC522Debug_h

	// Get humanable code and type
	 const char *PICC_GetTypeNameExtended(PICC_Type type);
	 const char *GetStatusCodeName_(StatusCode code);

#endif // MFRC522Debug_h
