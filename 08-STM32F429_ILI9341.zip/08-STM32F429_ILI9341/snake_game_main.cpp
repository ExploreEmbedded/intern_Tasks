#include<iostream>
#include<stdlib.h>
//#include<conio.h>
#include "tm_stm32f4_ili9341.h"
using namespace std;

bool GameOver;
const int width = 320;
const int height = 240;
int snakex,snakey,foodx,foody,score,speed;
int ntail=0;
int tailx[100];
int taily[100];
enum Direction{STOP=0, LEFT, RIGHT, UP, DOWN};
Direction D;

void delay()
{
    for(int i=0; i<speed;i++)
    {
        for(int j=0;j<speed;j++)
        {
            for(int k=0;k<speed;k++)
            {

            }
        }
    }
}

void setup()
{
    speed = 300;
    GameOver = false;
    D = STOP;
    snakex = width/2;
    snakey = height/2;
    foodx = rand() % width;
    foody = rand() % height;
    score = 0;
}

void draw()
{
//    system("cls");
//clear screen first i.e. fill screen with black. it is akready done in main
//    for (int i=0;i<width+2;i++)
//    {
//        cout<<"#";
//    }
//    cout<<endl;
// draw borders
	TM_ILI9341_DrawLine(0,0,0,240,0xffff);
	TM_ILI9341_DrawLine(0,0,320,0,0xffff);
	TM_ILI9341_DrawLine(320,0,320,240,0xffff);
	TM_ILI9341_DrawLine(0,240,320,240,0xffff);
	
    for(int i=0; i<height; i++)
    {
        for(int j=0; j<width; j++)
        {
            //if(j==0)
                //cout<<"#";

                    if(j==snakex && i==snakey )
                  //  cout<<"O";
                    else if(j==foodx && i==foody)
                    cout<<"*";
            else
            {
                bool print=false;
                for(int k=0; k<ntail;k++)
                {
                    if(tailx[k]==j && taily[k]==i)
                    {
                        cout<<"o";
                        print=true;
                    }
                }
                if(!print)
                    cout<<" ";

            }
             if(j==(width-1))
                    cout<<"#";
        }
        cout<<endl;
    }
    for (int i=0;i<width+2;i++)
    {
        cout<<"#";
    }
    cout<<endl;
    cout <<"Your Score : "<<score;
}

void input()
{
    if(_kbhit())
    {
        switch (_getch())
        {
        case 'a':
            D=LEFT;
            break;
        case 's':
            D=DOWN;
            break;
        case 'w':
            D=UP;
            break;
        case 'd':
            D=RIGHT;
            break;
        case 'q':
            GameOver=true;
            break;
         default :
            break;
        }
    }
}

void logic()
{

    int lastx=tailx[0];
    int lasty=taily[0];
    int last2x, last2y;
    tailx[0]=snakex;
    taily[0]=snakey;

    for (int i=1;i<ntail;i++)
    {
        last2x=tailx[i];
        last2y=taily[i];
        tailx[i]=lastx;
        taily[i]=lasty;
        lastx=last2x;
        lasty=last2y;
    }
    switch(D)
    {
    case UP :
        if(snakey==0)
        {
           cout<<"GAME OVER!!";
           GameOver=true;
           cout<<score;
           break;
        }
        snakey--;
        break;
    case DOWN :
        if(snakey==height-1)
        {
           cout<<"GAME OVER!!";
           GameOver=true;
           cout<<score;
           break;
        }
        snakey++;
        break;
    case LEFT :
        if(snakex==0)
         {
           cout<<"GAME OVER!!";
           GameOver=true;
           cout<<score;
           break;
        }
        snakex--;
        break;
    case RIGHT :
        if(snakex==width-1)
        {
           cout<<"   GAME OVER!!";
           GameOver=true;

           break;
        }
        snakex++;
        break;
    default :
        break;
    }
    for(int i=0;i<ntail;i++)
    {
       if(tailx[i]==snakex && taily[i]==snakey)
       {

           cout<<"   GAME OVER!!";
           GameOver=true;
       }
    }

    if(snakex==foodx && snakey==foody)
    {
         foodx = rand() % width;
         foody = rand() % height;
         score++;
         ntail++;
    }
}

int main()
{
        setup();
   while(!GameOver)
    {
        draw();
        input();
        logic();
        delay();                    //sleep(10); //for slowing game
    }
        return 0;
}



