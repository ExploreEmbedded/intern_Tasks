#ifndef MFRC522HACK_H
#define MFRC522HACK_H

#include "MFRC522.h"
#include "MFRC522Debug.h"


	//MFRC522 *const _device;

	//MFRC522Hack(MFRC522 *const device) : _device(device) {};

	bool MIFARE_OpenUidBackdoor(const bool logErrors);

	bool MIFARE_SetUid(const unsigned char *newUid, const unsigned char uidSize, const bool logErrors);

	bool MIFARE_UnbrickUidSector(const bool logErrors) ;


#endif //MFRC522HACK_H
