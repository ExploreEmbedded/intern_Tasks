#include "MFRC522Hack.h"

/**
 * Performs the "magic sequence" needed to get Chinese UID changeable
 * Mifare cards to allow writing to sector 0, where the card UID is stored.
 *
 * Note that you do not need to have selected the card through REQA or WUPA,
 * this sequence works immediately when the card is in the reader vicinity.
 * This means you can use this method even on "bricked" cards that your reader does
 * not recognise anymore (see MFRC522Hack::MIFARE_UnbrickUidSector).
 *
 * Of course with non-bricked devices, you're free to select them before calling this function.
 */
bool MIFARE_OpenUidBackdoor(const bool logErrors) /*const*/ {
	// Magic sequence:
	// > 50 00 57 CD (HALT + CRC)
	// > 40 (7 bits only)
	// < A (4 bits only)
	// > 43
	// < A (4 bits only)
	// Then you can write to sector 0 without authenticating

	 /*_device->*/PICC_HaltA(); // 50 00 57 CD

	unsigned char cmd = 0x40;
	unsigned char validBits = 7; /* Our command is only 7 bits. After receiving card response,
						  this will contain amount of valid response bits. */
	unsigned char response[32]; // Card's response is written here
	unsigned char received;
	StatusCode status =  /*_device->*/PCD_TransceiveData(&cmd, (unsigned char) 1, response, &received, &validBits, (unsigned char) 0,
														 false); // 40
	if (status != STATUS_OK) {
		if (logErrors) {
			printf("Card did not respond to 0x40 after HALT command. Are you sure it is a UID changeable one?");
			printf("Error name: ");
			printf("\n%s",GetStatusCodeName(status));

		}
		return false;
	}
	if (received != 1 || response[0] != 0x0A) {
		if (logErrors) {
			printf("Got bad response on backdoor 0x40 command: ");
			printf("%x",response[0]);
			printf(" (");
			printf("%c",validBits);
			printf(" valid bits)\r\n");
		}
		return false;
	}

	cmd = 0x43;
	validBits = 8;
	status =  /*_device->*/PCD_TransceiveData(&cmd, (unsigned char) 1, response, &received, &validBits, (unsigned char) 0, false); // 43
	if (status != STATUS_OK) {
		if (logErrors) {
			printf("Error in communication at command 0x43, after successfully executing 0x40");
			printf("Error name: ");
			printf("\n%s",GetStatusCodeName(status));
		}
		return false;
	}
	if (received != 1 || response[0] != 0x0A) {
		if (logErrors) {
			printf("Got bad response on backdoor 0x43 command: ");
			printf("%x",response[0]);
			printf(" (");
			printf("%c",validBits);
			printf(" valid bits)\r\n");
		}
		return false;
	}

	// You can now write to sector 0 without authenticating!
	return true;
} // End MIFARE_OpenUidBackdoor()

/**
 * Reads entire block 0, including all manufacturer data, and overwrites
 * that block with the new UID, a freshly calculated BCC, and the original
 * manufacturer data.
 *
 * It assumes a default KEY A of 0xFFFFFFFFFFFF.
 * Make sure to have selected the card before this function is called.
 */
bool MIFARE_SetUid(const unsigned char *newUid, const unsigned char uidSize, const bool logErrors)  {

	// UID + BCC unsigned char can not be larger than 16 together
	if (!newUid || !uidSize || uidSize > 15) {
		if (logErrors) {
			printf("New UID buffer empty, size 0, or size > 15 given");
		}
		return false;
	}

	// Authenticate for reading
	MIFARE_Key key = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
	StatusCode status =  /*_device->*/PCD_Authenticate(PICC_CMD_MF_AUTH_KEY_A, (unsigned char) 1, &key, &( /*_device->*/uid));
	if (status != STATUS_OK) {

		if (status == STATUS_TIMEOUT) {
			// We get a read timeout if no card is selected yet, so let's select one

			// Wake the card up again if sleeping
//			  unsigned char atqa_answer[2];
//			  unsigned char atqa_size = 2;
//			  PICC_WakeupA(atqa_answer, &atqa_size);

			if (! /*_device->*/PICC_IsNewCardPresent() || ! /*_device->*/PICC_ReadCardSerial()) {
				printf("No card was previously selected, and none are available. Failed to set UID.");
				return false;
			}

			status =  /*_device->*/PCD_Authenticate(PICC_CMD_MF_AUTH_KEY_A, (unsigned char) 1, &key, &( /*_device->*/uid));
			if (status != STATUS_OK) {
				// We tried, time to give up
				if (logErrors) {
					printf("Failed to authenticate to card for reading, could not set UID: ");
					printf("%s",GetStatusCodeName(status));
				}
				return false;
			}
		} else {
			if (logErrors) {
				printf("PCD_Authenticate() failed: ");
				printf("%s",GetStatusCodeName(status));
			}
			return false;
		}
	}

	// Read block 0
	unsigned char block0_buffer[18];
	unsigned char byteCount = sizeof(block0_buffer);
	status =  /*_device->*/MIFARE_Read((unsigned char) 0, block0_buffer, &byteCount);
	if (status != STATUS_OK) {
		if (logErrors) {
			printf("MIFARE_Read() failed: ");
			printf("\n%s",GetStatusCodeName(status));
			printf("Are you sure your KEY A for sector 0 is 0xFFFFFFFFFFFF?");
		}
		return false;
	}

	// Write new UID to the data we just read, and calculate BCC byte
	unsigned char bcc = 0;
	for (uint8_t i = 0; i < uidSize; i++) {
		block0_buffer[i] = newUid[i];
		bcc ^= newUid[i];
	}

	// Write BCC unsigned char to buffer
	block0_buffer[uidSize] = bcc;

	// Stop encrypted traffic so we can send raw bytes
	 /*_device->*/PCD_StopCrypto1();

	// Activate UID backdoor
	if (!MIFARE_OpenUidBackdoor(logErrors)) {
		if (logErrors) {
			printf("Activating the UID backdoor failed.");
		}
		return false;
	}

	// Write modified block 0 back to card
	status =  /*_device->*/MIFARE_Write((unsigned char) 0, block0_buffer, (unsigned char) 16);
	if (status != STATUS_OK) {
		if (logErrors) {
			printf("MIFARE_Write() failed: ");
			printf("%s",GetStatusCodeName(status));
		}
		return false;
	}

	// Wake the card up again
	unsigned char atqa_answer[2];
	unsigned char atqa_size = 2;
	 /*_device->*/PICC_WakeupA(atqa_answer, &atqa_size);

	return true;
}

/**
 * Resets entire sector 0 to zeroes, so the card can be read again by readers.
 */
bool MIFARE_UnbrickUidSector(const bool logErrors)  {
	MIFARE_OpenUidBackdoor(logErrors);

	unsigned char block0_buffer[] = {0x01, 0x02, 0x03, 0x04, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
							0x00};

	// Write modified block 0 back to card
	StatusCode status =  /*_device->*/MIFARE_Write((unsigned char) 0, block0_buffer, (unsigned char) 16);
	if (status != STATUS_OK) {
		if (logErrors) {
			printf("MIFARE_Write() failed: ");
			printf("\n%s",GetStatusCodeName(status));
		}
		return false;
	}
	return true;
}
