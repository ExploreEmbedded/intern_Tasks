#include <iostream>
#include <stdlib.h>
//#include <conio.h>

void delay();
void setup();
void draw();
void input();
void logic();
