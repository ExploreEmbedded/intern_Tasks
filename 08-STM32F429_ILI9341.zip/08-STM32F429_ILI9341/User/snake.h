void draw();
void setup();
void logic();
void input();
