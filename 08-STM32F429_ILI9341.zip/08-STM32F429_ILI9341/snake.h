#include "tm_stm32f4_ili9341.h"
#include "tm_stm32f4_adc.h"
#include <stdio.h>
#include <stdlib.h>

#define STOP 0
#define LEFT 1
#define RIGHT 2
#define UP 3
#define DOWN 4

//bool GameOver;
int GameOver;
const int width = 320;
const int height = 240;
int snakex,snakey,foodx,foody,score, flagclear,startflag;//speed;
int ntail=1;
int tailx[100] = {160};//,160,160,160,160};
int taily[100] = {120};//,115,110,105,100};
char s[10];
long int f;

int D,i,j,k,l,dold, xtail, ytail;

void draw(void);
void setup(void);
void logic(void);
void input(void);
//void delay();


