#include "tm_stm32f4_ili9341.h"
#include "tm_stm32f4_adc.h"
#include <stdio.h>
#define STOP 0
#define LEFT 1
#define RIGHT 2
#define UP 3
#define DOWN 4

//bool GameOver;
int GameOver,print;
const int width = 20;
const int height = 20;
int snakex,snakey,foodx,foody,score,speed;
int ntail=0;
int tailx[100];
int taily[100];
char s[10];
//enum Direction{STOP=0, LEFT, RIGHT, UP, DOWN};
//Direction D;
int D,i,j,k,l;

void delay()
{
    for(int i=0; i<speed;i++)
    {
        for(int j=0;j<speed;j++)
        {
            for(int k=0;k<speed;k++)
            {

            }
        }
    }
}
void setup()
{
    speed = 300;
    //GameOver = false;
		GameOver = 0;
    D = STOP;
    snakex = width/2;
    snakey = height/2;
    foodx = rand() % width;
    foody = rand() % height;
    score = 0;
}
void draw()
{		/* clear screen, i.e. fill black */
		TM_ILI9341_Fill(ILI9341_COLOR_BLACK);
	/* draw borders on all 4 edges */
		TM_ILI9341_DrawLine(0,0,0,240,ILI9341_COLOR_WHITE);	//LHS border
		TM_ILI9341_DrawLine(0,0,320,0,ILI9341_COLOR_WHITE);	//bottom border
		TM_ILI9341_DrawLine(0,240,320,240,ILI9341_COLOR_WHITE);	//top border
		TM_ILI9341_DrawLine(320,240,320,0,ILI9341_COLOR_WHITE);//RHS border
		// print head of snake first
		if(j==snakex && i==snakey)
				TM_ILI9341_DrawFilledRectangle(j-5,i-5,j+5,i+5,ILI9341_COLOR_YELLOW);
		// print food
		else if (j==foodx && i==foody)
				TM_ILI9341_DrawFilledRectangle(j-3,i-3,j+3,i+3,ILI9341_COLOR_GREEN2);
		// print tail
		else
		{
		//		print = 0;
			for(k=0; k<ntail; k++)
			{
					if(tailx[k]==j && taily[k]==i)
					{
							TM_ILI9341_DrawFilledRectangle(j-3,i-3,j+3,i+3,ILI9341_COLOR_WHITE);
		//					print = 1;
					}
			}
		}
		// convert score to string and display on lcd
		sprintf(s,"%4d \n\r",score);
		TM_ILI9341_Puts(0,230,s,&TM_Font_11x18,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
}
void input()
{
		if (TM_ADC_Read(ADC1, ADC_Channel_0) < 1900)
		{
				D = UP;
				//TM_ILI9341_DrawFilledCircle(160, 120, 10, ILI9341_COLOR_BLUE);
		}
		else if (TM_ADC_Read(ADC1, ADC_Channel_0) > 2100)
		{
				D = DOWN;
				//TM_ILI9341_DrawFilledCircle(160, 120, 10, ILI9341_COLOR_ORANGE);
		}
		else if (TM_ADC_Read(ADC1, ADC_Channel_3) < 1900)
		{
				D = RIGHT;
				//TM_ILI9341_DrawFilledCircle(160, 120, 10, ILI9341_COLOR_RED);
		}
		else if (TM_ADC_Read(ADC1, ADC_Channel_3) > 2100)
		{
				D = LEFT;
				//TM_ILI9341_DrawFilledCircle(160, 120, 10, ILI9341_COLOR_GREEN);
		}
		else
		{
				//TM_ILI9341_DrawFilledCircle(160, 120, 10, ILI9341_COLOR_WHITE);
		}
}
void logic()
{
		int lastx=tailx[0];
    int lasty=taily[0];
    int last2x, last2y;
    tailx[0]=snakex;
    taily[0]=snakey;

    for (int i=1;i<ntail;i++)
    {
        last2x=tailx[i];
        last2y=taily[i];
        tailx[i]=lastx;
        taily[i]=lasty;
        lastx=last2x;
        lasty=last2y;
		}
		switch(D)
		{
			case UP:
				if(snakey==0)
        {//print gameover
					TM_ILI9341_Puts(0,0,"GAME OVER !!!",&TM_Font_16x26,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
					
           //cout<<"GAME OVER!!";
           GameOver=1;
          // cout<<score;
					sprintf(s,"%4d \n\r",score);
					TM_ILI9341_Puts(0,230,s,&TM_Font_11x18,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
           break;
        }
        snakey--;
        break;
    case DOWN :
        if(snakey==height-1)
        {
						TM_ILI9341_Puts(0,0,"GAME OVER !!!",&TM_Font_16x26,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
          // cout<<"GAME OVER!!";
           GameOver=1;
          // cout<<score;
					sprintf(s,"%4d \n\r",score);
		TM_ILI9341_Puts(0,230,s,&TM_Font_11x18,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
           break;
        }
        snakey++;
        break;
    case LEFT :
        if(snakex==0)
         {
					 	TM_ILI9341_Puts(0,0,"GAME OVER !!!",&TM_Font_16x26,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
       //    cout<<"GAME OVER!!";
           GameOver=1;
           //cout<<score;
					 sprintf(s,"%4d \n\r",score);
		TM_ILI9341_Puts(0,230,s,&TM_Font_11x18,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
           break;
        }
        snakex--;
        break;
    case RIGHT :
        if(snakex==width-1)
        {
						TM_ILI9341_Puts(0,0,"GAME OVER !!!",&TM_Font_16x26,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
          // cout<<"   GAME OVER!!";
           GameOver=1;
sprintf(s,"%4d \n\r",score);
		TM_ILI9341_Puts(0,230,s,&TM_Font_11x18,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
           break;
        }
        snakex++;
        break;
    default :
        break;
    }
    for(int i=0;i<ntail;i++)
    {
       if(tailx[i]==snakex && taily[i]==snakey)
       {

          	TM_ILI9341_Puts(0,0,"GAME OVER !!!",&TM_Font_16x26,ILI9341_COLOR_WHITE,ILI9341_COLOR_BLACK);
           GameOver=1;
       }
    }

    if(snakex==foodx && snakey==foody)
    {
         foodx = rand() % width;
         foody = rand() % height;
         score++;
         ntail++;
    }
		}
